from pathlib import Path
import vtk
import numpy as np
P=Path(__file__).parent
sources=[
 ('01_socle_FR7_downfiring.stl',(0.18,.2,.23),1),
 ('02_caisson_acoustique.stl',(0.17,.20,.24),1),
 ('03_cloison_etanche.stl',(0.42,.39,.33),.97),
 ('04_corps_galet_electronique.stl',(0.22,.25,.30),1),
 ('05_couronne_XVF3800_plexiglas.stl',(0.14,.16,.20),1),
 ('06_logement_ecran_rond_185.stl',(0.055,.07,.09),1),
 ('08_gabarit_plexi_fume_NON_IMPRIMER.stl',(0.05,.09,.14),.60)]
ren=vtk.vtkRenderer();ren.SetBackground(0.94,0.95,0.96)
ren.SetBackground2(1,1,1);ren.GradientBackgroundOn()
for i,(fn,col,alpha) in enumerate(sources):
 reader=vtk.vtkSTLReader();reader.SetFileName(str(P/fn));reader.Update()
 mapper=vtk.vtkPolyDataMapper();mapper.SetInputConnection(reader.GetOutputPort())
 actor=vtk.vtkActor();actor.SetMapper(mapper);actor.GetProperty().SetColor(*col)
 actor.GetProperty().SetOpacity(alpha);actor.GetProperty().SetSpecular(.20)
 actor.GetProperty().SetSpecularPower(30)
 if i==5:
  actor.RotateX(-90);actor.AddPosition(0,-73,72)
 if i==6:actor.AddPosition(0,0,109.0)
 ren.AddActor(actor)
# LED disk and screen simulated, explicitly visual only
screen=vtk.vtkDiskSource();screen.SetInnerRadius(19);screen.SetOuterRadius(23.1);screen.SetCircumferentialResolution(96)
map2=vtk.vtkPolyDataMapper();map2.SetInputConnection(screen.GetOutputPort())
act=vtk.vtkActor();act.SetMapper(map2);act.GetProperty().SetColor(.17,.58,.96)
# disc XY -> XZ plane, normal -Y
act.RotateX(90);act.AddPosition(0,-73.2,72);ren.AddActor(act)
ring=vtk.vtkDiskSource();ring.SetInnerRadius(11.8);ring.SetOuterRadius(12.3);ring.SetCircumferentialResolution(96)
m=vtk.vtkPolyDataMapper();m.SetInputConnection(ring.GetOutputPort())
a=vtk.vtkActor();a.SetMapper(m);a.GetProperty().SetColor(.22,.71,1.0);a.AddPosition(0,0,111.2);ren.AddActor(a)
ren.AutomaticLightCreationOn()
window=vtk.vtkRenderWindow();window.SetSize(1300,980);window.AddRenderer(ren);window.SetOffScreenRendering(1)
cam=ren.GetActiveCamera();cam.SetPosition(215,-275,170);cam.SetFocalPoint(0,0,52);cam.SetViewUp(0,0,1)
ren.ResetCameraClippingRange();cam.SetParallelProjection(True);cam.SetParallelScale(124)
window.Render()
snap=vtk.vtkWindowToImageFilter();snap.SetInput(window);snap.Update()
w=vtk.vtkPNGWriter();w.SetFileName(str(P/'rendu_3d_v2.png'));w.SetInputConnection(snap.GetOutputPort());w.Write()
print('Rendered VTK',P/'rendu_3d_v2.png')
